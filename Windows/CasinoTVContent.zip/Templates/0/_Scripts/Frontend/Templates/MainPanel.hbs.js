﻿(function ($) {
    $.templates['MainPanel'] =
        '<div id="main-form" class="main-form">\
                <div id="main" class="wpPluginMain">\
                    <div id="container">\
                        <div id="content" role="main">\
                            <div id="sectionHomepage">\
                            </div>\
                                    {{#eachProp data}}\
                                    {{#ifEqual index 0}}\
                                         <div id="home_gameList">\
                                                    <div class="home_headerGame">\
                                                        <hr style="opacity: 0; width: 100%;">\
                                                        <div style="float: left; text-align: left; margin-left: 25px;"><h1 style="font-size: 15px;">{{key}}</h1></div>\
                                                        <div style="position: absolute; right: 55px;"><a href="./games" style="color: #344d18;"> » all games</a></div>\
                                                    </div>\
                                                    <div class="wx-ne-matrix-games-grid">\
                                                                <div class="wx-ne-matrix-page-stripe">\
                                                                    <div id="selected-category" class="wx-ne-matrix-page-container">\
                                                                        {{partial "GameCategory" .  index "" ../../data.settings}}\
                                                                    </div>\
                                                                </div>\
                                                    </div>\
                                        </div>\
                                    {{/ifEqual}}\
                                    {{#ifEqual index 1}}\
                                         <div id="home_gameList">\
                                                    <div class="home_headerGame">\
                                                        <hr style="opacity: 0; width: 100%;">\
                                                        <div style="float: left; text-align: left; margin-left: 25px;"><h1 style="font-size: 15px;">{{key}}</h1></div>\
                                                        <div style="position: absolute; right: 55px;"><a href="./games" style="color: #344d18;"> » all games</a></div>\
                                                    </div>\
                                                    <div class="wx-ne-matrix-games-grid">\
                                                                <div class="wx-ne-matrix-page-stripe">\
                                                                    <div id="selected-category" class="wx-ne-matrix-page-container">\
                                                                        {{partial "GameCategory" .  @index "" ../../data.settings}}\
                                                                    </div>\
                                                                </div>\
                                                    </div>\
                                        </div>\
                                    {{/ifEqual}}\
                                    {{/eachProp}}\
                    </div>\
                </div>\
            </div';
})(jQuery);


