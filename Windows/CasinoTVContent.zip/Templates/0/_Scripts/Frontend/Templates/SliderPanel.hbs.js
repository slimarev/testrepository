﻿(function ($) {
    $.templates['SliderPanel'] =
    '<div><div id="sliderTv_noshade">\
       </div>\
      <div  class="slider">\
      <ul id="slider-{{data.id}}" class="slider_wrapper" heigth="300px">\
        {{#each data.games}}\
        <li class="slider_item">\
            <div style="height:100%"><img src="{{ImageUrl}}" style="height:100%"></img>\
        <div style="position: absolute;top: 340px;width: 100%;">\
        <div id="{{gameId}}" class="slider_play_btn">\
        <a href="./game/{{GameId}}"><div id="{{GameId}}" class="wx-ne-matrix-item-playbtn home_img_play">Play</div></a>\
        <a href="./game/{{GameId}}"><div id="{{GameId}}" class="wx-ne-matrix-item-playbtn home_img_playFF">Play for Fun</div></a>\
        </div>\
        </div>\
        </div>\
        </li>\
        {{/each}}\
      </ul>\
    </div>\
    </div>';
})(jQuery);

