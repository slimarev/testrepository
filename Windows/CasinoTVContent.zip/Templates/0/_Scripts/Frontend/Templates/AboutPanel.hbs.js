﻿(function ($) {
    $.templates['AboutPanel'] =
        '<div class="containerWrapper">\
    <div id="sectionHomepage">\
        <div id="globalContent" style="top: 20px;">\
            <div class="containerSection">\
                <aside>\
                    <strong>QUICK LINKS</strong>\
                    <hr style="clear:left;opacity:0;width:100%;margin: 8px;">\
                    <div class="menu-about-us-container">\
                        <ul id="menu-about-us" class="menu-about">\
                            <li id="menu-item-15" class="menu-item menu-item-type-post_type menu-item-object-page {{#ifEqual data.currentPage "about-us"}}current_page_item{{/ifEqual}}" ><a pageId="about-us">ABOUT US</a></li>\
                            <li id="menu-item-57" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-57 {{#ifEqual data.currentPage "good-gaming"}}current_page_item{{/ifEqual}}" ><a pageId="good-gaming">GOOD GAMING</a></li>\
                            <li id="menu-item-474" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-474 {{#ifEqual data.currentPage "jackpots"}}current_page_item{{/ifEqual}}" ><a pageId="jackpots" >JACKPOTS</a></li>\
                            <li id="menu-item-60" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-60 {{#ifEqual data.currentPage "background"}}current_page_item{{/ifEqual}}" ><a pageId="background" >BACKGROUND</a></li>\
                            <li id="menu-item-66" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-66 {{#ifEqual data.currentPage "legal"}}current_page_item{{/ifEqual}}" ><a pageId="legal">LEGAL</a></li>\
                            <li id="menu-item-65" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-65 {{#ifEqual data.currentPage "deposits"}}current_page_item{{/ifEqual}}" ><a pageId="deposits">DEPOSITS</a></li>\
                            <li id="menu-item-69" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-69 {{#ifEqual data.currentPage "winnings"}}current_page_item{{/ifEqual}}" ><a pageId="winnings">WINNINGS</a></li>\
                        </ul>\
                    </div>\
                </aside>\
                <div id="aboutPanel">\
                    <div class="at_content">\
                        <div id="about_content" class="about_content">\
                        </div>\
                    </div>\
                    <div id="vintageTv_noshade">\
                    </div>\
                </div>\
            </div>\
        </div>\
    </div>\
</div>\
           <script>\
            $(".menu-item").on("click",function(event){\
            if($(event.target).attr("pageId")){$(".menu-item").removeClass("current_page_item");\
            $(event.target).parent().addClass("current_page_item");\
            $("#about_content").html("");\
            goTo($(event.target).attr("pageId"));\
            }})\
           </script>';
})(jQuery);


