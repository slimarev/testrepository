﻿(function ($) {
    $.templates['UserPanel'] =
 '<div class="isLogged"><div  class="user_profile"><div style=" font-size: 20px; ">{{nick}}</div><div  style=" font-size: 20px; ">€<label id="gambler_balance">{{balance}}</label></div><div style=" opacity: 0.7; ">balance</div></div>\
     <div id="Logout" class="logout">Logout</div>\
        </div>\
</div>\
    <script>\
    $(".logout").click(function(){\
         doAction("Logout","Global")});\
    $(".floatMenu").click(function (event) {\
        var menuItem=$("#"+event.target.id).parent().find( ".head_dialogMenu");\
    if(menuItem.is(":visible")) $(".head_dialogMenu").hide(); else {$(".head_dialogMenu").hide();menuItem.show();}\
    }); \
    $(".head_dialogMenu").mouseleave(function() {\
        $(".head_dialogMenu").hide();\
    });\
    </script>';
})(jQuery);


