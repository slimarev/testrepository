﻿(function ($) {
    $.templates['DashboardPanel'] =
        '<div class="containerWrapper">\
    <div id="sectionHomepage">\
        <div id="globalContent" style="top: 20px;width: 100%;min-height: 200px;">\
            <div class="containerSection" style="display: flex;">\
                <aside>\
                    <strong>MY HOME QUICK LINKS</strong>\
                    <hr style="clear:left;opacity:0;width:100%;margin: 8px;">\
                    <div class="menu-about-us-container">\
                        <ul id="menu-about-us" class="menu-about">\
                            <li id="menu-item-15" class="menu-item menu-item-type-post_type menu-item-object-page {{#ifEqual data.currentPage "home_overview"}}current_page_item{{/ifEqual}}" ><a  pageId="home_overview">MY HOME OVERVIEW</a></li>\
                            <li id="menu-item-15" class="menu-item menu-item-type-post_type menu-item-object-page {{#ifEqual data.currentPage "EditProfile"}}current_page_item{{/ifEqual}}" ><a  type="mva" pageId="EditProfile">EDIT PROFILE</a></li>\
                            <li id="menu-item-57" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-57 {{#ifEqual data.currentPage "ChangePassword"}}current_page_item{{/ifEqual}}" ><a type="mva" pageId="ChangePassword">CHANGE PASSWORD</a></li>\
                            <li id="menu-item-474" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-474 {{#ifEqual data.currentPage "transaction_report_page"}}current_page_item{{/ifEqual}}" ><a pageId="transaction_report_page" >TRANSACTION HISTORY</a></li>\
                            <li id="menu-item-60" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-60 {{#ifEqual data.currentPage "withdraw_report_page"}}current_page_item{{/ifEqual}}" ><a pageId="withdraw_report_page" >REQUEST LIST</a></li>\
                            <li id="menu-item-66" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-66 {{#ifEqual data.currentPage "deposit_report_page"}}current_page_item{{/ifEqual}}" ><a pageId="deposit_report_page">DEPOSITS LIST</a></li>\
                            <li id="menu-item-65" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-65 {{#ifEqual data.currentPage "transaction_page"}}current_page_item{{/ifEqual}}" ><a pageId="deposits">TRANSACTION</a></li>\
                            <li id="menu-item-69" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-69 {{#ifEqual data.currentPage "deposit_page"}}current_page_item{{/ifEqual}}" ><a pageId="deposit_page">DEPOSIT</a></li>\
                            <li id="menu-item-69" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-69 {{#ifEqual data.currentPage "withdraw_page"}}current_page_item{{/ifEqual}}" ><a pageId="withdraw_page">WITHDRAWAL</a></li>\
                        </ul>\
                    </div>\
                </aside>\
                <div id="dashboardPanel" style="flex: 1;">\
                    <div class="user_info">\
                        <div  class="dashboard-item-header">\
                            <h4 style=" float: left;">{{data.userData.nick}}-</h4>\
                            <div class="account-id-lbl"> ACCOUNT ID: {{data.userData.accountId}}</div>\
                        </div>\
                        <hr class="separator">\
                        <div>\
                        <div class="info-row"><div>Balance:</div><label id="gambler_balance">{{data.userData.balance}}</label>€</div></div>\
                        </div>\
                    </div>\
                    <div class="customer_service" style="flex: 1;"> \
                        <div class="info_header">\
                            <div class="dashboard-item-header"> <h4>CUSTOMER SERVICE</h4></div>\
                            <hr class="separator">\
                            <label>Email:customerservice@casinotv.com</label>\
                        </div>\
                    </div>\
                </div>\
            </div>\
        </div>\
    </div>\
</div>\
           <script>\
            $(".menu-item").on("click",function(event){\
            if($(event.target).attr("type")=="mva")\
            doAction($(event.target).attr("pageId"),"Global");\
            else{\
            showPopup($(event.target).attr("pageId"));\
            }})\
           </script>';
})(jQuery);


