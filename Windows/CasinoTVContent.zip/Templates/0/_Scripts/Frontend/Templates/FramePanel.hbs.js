﻿(function ($) {
    $.templates['FramePanel'] =
        '<div  class="frame-wrap"> \
           <iframe src="{{data}}"  width="99%" height="94%" style="position:absolute; " frameborder="0"  marginwidth="0" ></iframe>\
        </div>';
})(jQuery);