﻿(function ($) {
    $.controls['LinkPartial'] =
         '<a href={{url}} class="a">{{text}}</a>';
})(jQuery);

