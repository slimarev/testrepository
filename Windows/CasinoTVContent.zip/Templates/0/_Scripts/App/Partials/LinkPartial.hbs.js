﻿(function ($) {
    $.controls['LinkPartial'] =
         '<a href={{url}} class="a" target="_blank"> {{text}}</a>';
})(jQuery);

