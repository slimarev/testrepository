﻿(function ($) {
    $.controls['LabelPartial'] =
        '<div  class="input-row {{#if settings.inlineInput}}input-inline{{/if}}"> \
         <label class="field_label">{{compile Name.template Name.data}}</label> \
          <label id={{ModelId}}-{{Id}} class="field_label"  value={{Value}}>{{Value}}</label></div>\
          {{#if  Attributes.separator}}<hr class="separator"></hr>{{/if}}';
})(jQuery);
