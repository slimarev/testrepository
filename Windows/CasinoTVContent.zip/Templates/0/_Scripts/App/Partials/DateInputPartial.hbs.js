﻿(function ($) {
    $.dobDateTimePicker = function (id,defautDate) {
        var minYear = 1976;
        var maxYear = new Date().getFullYear() + 5;
        var months = [
            { "id": 1, "name": "January" },
            { "id": 2, "name": "February" },
            { "id": 3, "name": "March" },
            { "id": 4, "name": "April" },
            { "id": 5, "name": "May" },
            { "id": 6, "name": "June" },
            { "id": 7, "name": "July" },
            { "id": 8, "name": "August" },
            { "id": 9, "name": "September" },
            { "id": 10, "name": "October" },
            { "id": 11, "name": "November" },
            { "id": 12, "name": "December" }
        ];
        var maxMonthDay = 31;
        var selectedDate = new Date(defautDate) || new Date();
        var selectedDay = ""+selectedDate.getDate();
        var selectedMonth = ""+(selectedDate.getMonth() + 1);
        var selectedYear = ""+selectedDate.getFullYear();

        function updatePickerData() {
            $('#year-' + id).empty();

            $('#year-' + id).append("<option value=0>--</option>");
            for (var year = minYear; year < maxYear; year++) {
                $('#year-' + id).append("<option value=" + year + ">" + year + "</option>");
            }
            $('#year-' + id).val(selectedYear);

            $('#month-' + id).empty();
            $('#month-' + id).append("<option value=0>--</option>");
            $.each(months, function (index, month) {
                $('#month-' + id).append("<option value=" + month.id + ">" + month.name + "</option>");
            });
            $('#month-' + id).val(selectedMonth);

            $('#day-' + id).empty();
            $('#day-' + id).append("<option value=0>--</option>");
            for (var day = 1; day <= maxMonthDay; day++) {
                $('#day-' + id).append("<option value=" + day + ">" + day + "</option>");
            }
            $('#day-' + id).val(selectedDay);
        }

        function updateDate() {
            $('#' + id).val($.DateFormat(selectedYear + "-" + (selectedMonth.length < 2 ? "0" + selectedMonth : selectedMonth) + "-" + (selectedDay.length < 2 ? "0" + selectedDay : selectedDay) + " 00:00:00", "yyyy-MM-dd  HH:mm:ss"));
        }
        function clearDate() {
            $('#' + id).val("0000-00-00 00:00:00");
        }
        $('#year-' + id).change(function () {
            selectedYear = $(this).val();
            updatePickerData();
            if ($(this).val() != 0) {
            maxMonthDay = new Date($(this).val(), selectedMonth, 0).getDate();
            updateDate();
            } else {
                clearDate();
            }
        });
        $('#month-' + id).change(function () {
            selectedMonth = $(this).val();
            updatePickerData();
            if ($(this).val() != 0) {
            maxMonthDay = new Date(selectedYear, $(this).val(), 0).getDate();
                updateDate();
            } else {
                clearDate();
            }
         });
        $('#day-' + id).change(function () {
            selectedDay = $(this).val();
            updatePickerData();
            if ($(this).val() != 0) {
                updateDate();
            } else {
                clearDate();
            }
        });
        updatePickerData();
    };
    
    $.controls['DateInputPartial'] =
        '<div class="input-row {{#if settings.inlineInput}}input-inline{{/if}}" style="padding-top:{{settings.paddingTop}}px;padding-bottom:{{settings.paddingBottom}}px"> \
          <label class="field_label">{{compile Name.template Name.data}} \
          {{#if IsRequired}}(<label class="requiredLabel">*</label>){{/if}}</label>\
          <div class="input-wrap">\
          {{#if Attributes.dropdown}}\
            <select id=day-{{ModelId}}-{{Id}} data-index={{index}} class="input list_field" style="height:{{multiply settings.heigth 2}}px;" value="{{Value}}"\
            {{#if IsReadonly}} disabled{{/if}}> \
            </select>\
            <select id=month-{{ModelId}}-{{Id}} data-index={{index}} class="input list_field" style="height:{{multiply settings.heigth 2}}px;" value="{{Value}}"\
            {{#if IsReadonly}} disabled{{/if}}> \
            </select>\
            <select id=year-{{ModelId}}-{{Id}} data-index={{index}} class="input list_field" style="height:{{multiply settings.heigth 2}}px;" value="{{Value}}"\
            {{#if IsReadonly}} disabled{{/if}}> \
            </select>\
          <input id={{ModelId}}-{{Id}}  type="text" class="input date_field" style="display:none;" data-index={{index}} value="{{Value}}" \
          {{#if IsReadonly}}readonly="readonly" {{/if}} > \
          {{else}}\
          <input id={{ModelId}}-{{Id}}  type="text" class="input date_field" style="height:{{settings.heigth}}px;" data-index={{index}} value="{{Value}}" \
          {{#if IsReadonly}}readonly="readonly"{{/if}}> \
          {{/if}}\
          {{#if TooltipText}} {{partial "Tooltip" .}}{{/if}}\
         {{#if Description}}<label class="description-label" style="">{{compile Description.template Description.data}}</label>{{/if}}\
         </div>\
         </div>\
         <script>\
        if("{{Attributes.dropdown}}")\
        $.dobDateTimePicker("{{ModelId}}-{{Id}}",$.DateFormat("{{Value}}","yyyy-MM-dd"));\
           else{\
        if("{{Attributes.short}}")\
           $("#{{ModelId}}-{{Id}}").datetimepicker({value:$.DateFormat("{{Value}}","yyyy-MM-dd"),format:"Y-m-d",timepicker:false});\
        else\
           $("#{{ModelId}}-{{Id}}").datetimepicker({format:"Y-m-d H:i:s",timepicker:true});}\
    </script>';
 
})(jQuery);

