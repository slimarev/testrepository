﻿(function ($) {
    $.controls['ArrayPartial'] =
        '<div class="input-row {{#if settings.inlineInput}}input-inline{{/if}}" style="padding-top:{{settings.paddingTop}}px;padding-bottom:{{settings.paddingBottom}}px"> \
        <label class="field_label">{{compile Name.template Name.data}} \
        {{#if IsRequired}}(<label class="requiredLabel">*</label>){{/if}}</label>\
        <div class="input-wrap"><div style="display: flex;"><div><div class="list_header">All:</div><select id=list-{{ModelId}}-{{Id}} data-index={{index}} class="input multi_List" style="height:{{multiply settings.heigth "10"}}px;" multiple="multiple"\
        {{#if IsReadonly}} disabled{{/if}}> \
        {{#each ListOptions}}\
        {{#containsById . ../Value}}\
        {{else}}<option id={{Id}} value="{{Id}}"\
        {{#ifEqual Id ../Value}}\
        selected\
        {{/ifEqual}}>\
        {{#if Text.template}}{{compile Text.template Text.data}}{{/if}}</option>\
        {{/containsById}}\
        {{/each}}\
        </select></div>\
        <div style="margin-top: 5em"><div id="add-{{ModelId}}-{{Id}}" class="rigthArrow"></div><div id="remove-{{ModelId}}-{{Id}}" class="leftArrow"></div></div>\
        <div><div class="list_header">Selected:</div><select id=selected-{{ModelId}}-{{Id}} data-index={{index}} class="input multi_List" style="height:{{multiply settings.heigth "10"}}px;" multiple="multiple"\
        {{#if IsReadonly}} disabled{{/if}}> \
        {{#each Value}}\
        <option id={{Id}} value="{{Id}}"\
        {{#ifEqual Id ../Value}}\
        selected\
        {{/ifEqual}}>\
        {{#if Text.template}}{{compile Text.template Text.data}}{{/if}}</option>\
        {{/each}}\
        </select>\
        </div>\
        </div>\
        {{#if TooltipText}} {{partial "Tooltip" .}}{{/if}}\
        {{#if Description}}<label class="description-label" style="">{{compile Description.template Description.data}}</label>{{/if}}\
        </div> \
        </div>\
           <script>\
            $("#add-{{ModelId}}-{{Id}}").on("click",function(){\
              $("#list-{{ModelId}}-{{Id}}  option:selected").remove().appendTo("#selected-{{ModelId}}-{{Id}}");\
            });\
            $("#remove-{{ModelId}}-{{Id}}").on("click",function(){\
              $("#selected-{{ModelId}}-{{Id}}  option:selected").remove().appendTo("#list-{{ModelId}}-{{Id}}");\
            });\
            </script>';
})(jQuery);


