﻿(function($) {
    $.templates['AccordionFormTemplate'] =
        '{{#if settings.showMenu}}\
           {{#if data.GlobalActions}}\
            {{partial \'Menu\' data}}\
           {{/if}}\
        {{/if}}\
        <div class="form-wrap" style=\
        {{#if settings.layout.centered}}\
          display:block\
        {{/if}}>\
            <div class="form"\
             {{#if settings.layout.centered}}\
                style="display:block";\
                {{else}}\
                    {{#ifEqual settings.layout.float "left"}}\
                            style="float:left"\
                    {{else}}\
                        {{#ifEqual settings.layout.float "right"}}\
                            style="float:right"\
                        {{/ifEqual}}\
                    {{/ifEqual}}\
                  {{/if}}>\
           {{#if settings.showTitle}}<h1 class="form_title">{{data.Title}}{{/if}}</h1>\
            <div class="form_container" id="{{Id}}" style=display:{{#ifEqual ../settings.layout.type  "vertical"}}{{#if ../../settings.layout.centered}}table{{else}}block{{/if}}{{else}}flex;{{/ifEqual}}> \
                  <div id="accordion" class="accordion">\
                       {{#each data.accordionData}}\
                        {{#eachProp .}}\
                             <h3 class="accordion-header" id="{{value.id}}">{{value.name}}</h3>\
                             <div class="accordion-body">\
                                 {{#each value.fields}}\
                                    {{partial Type .  @index ../value.ModelId ../../../settings.fieldsSettings}} \
                                 {{/each}}\
                             </div>\
                        {{/eachProp}}\
                       {{/each}}\
                  </div>\
           </div>\
           {{partial "Actions" data}}\
             </div>\
        <script>$(function() {$.accordion=$("#accordion").accordion({autoHeight: false});});</script>';
})(jQuery);