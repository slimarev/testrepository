﻿BASE_SERVER_URL = "http://consumer.casinotv/";
BASE_SERVICE_URL = "http://service.casinotv/";
